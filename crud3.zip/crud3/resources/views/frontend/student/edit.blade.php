@extends('frontend.master')
@section('page-title')
    <h1 class="text-center py-5"> Add Student </h1>
@endsection
@section('main')
    <section class="add-student-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="py-3">
                        <div class="card p-5 shadow-sm border-1">
                            <p class="success">{{ Session::get('notify') }}</p>
                            <form action="/submit/{{$students->id}}" method="POST" enctype="multipart/form-data">
                                @csrf
                                {{ method_field('PUT') }}
                                <div class="mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" name="name" class="form-control" id="name" value="{{$students->name}}">
                                </div>
                                @error('name')
                                    <span class="error">{{ $message }}</span>
                                @enderror
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" id="email" value="{{$students->email}}">
                                </div>
                                @error('email')
                                    <span class="error">{{ $message }}</span>
                                @enderror
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control" id="password" value="{{$students->password}}">
                                </div>
                                @error('password')
                                    <span class="error">{{ $message }}</span>
                                @enderror
                                <div class="mb-3">
                                    <label for="image" class="form-label">Profile Image</label>
                                    <input type="file" accept="image/*" name="image" class="form-control"
                                        id="image">
                                </div>
                                @error('image')
                                    <span class="error">{{ $message }}</span>
                                @enderror
                                <div class="mb-3">
                                    <label for="roll" class="form-label">Set a roll</label>
                                    <select class="form-select" name="roll">
                                        <option value="1" selected>Admin</option>
                                        <option value="0">Student</option>
                                    </select>
                                </div>
                                <button type="submit" id="submit" class="btn btn-success">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-3"></div>
            </div>
        </div>
    </section>
@endsection
