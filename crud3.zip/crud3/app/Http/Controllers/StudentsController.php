<?php

namespace App\Http\Controllers;

use App\Models\Students;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;




class StudentsController extends Controller
{
    public function index()
    {
        return view('frontend.student.index');
    }

    public function store()
    {
        return view('frontend.student.add');
    }

    public function insertStudent(Request $request)
    {
        $students = new Students();
        $request->validate([
            'name' => 'required | max:60',
            'email' => 'required | max: 60',
            'password' => 'required | min:4 | max:20',
            'image' => 'required'
        ]);
        $students->name = $request->name;
        $students->email = $request->email;
        $students->password = $request->password;
        if ($request->hasFile('image')) {
            $destination = 'db/images/student/' . $students->image;
            if (File::exists($destination)) {
                File::delete($destination);
            }
            $file = $request->file('image');
            $fileName = 'student' . strtolower(Str::random(10)) . time() . '.' . $file->getClientOriginalExtension();
            $file->move('db/images/student/', $fileName);
            $students->image = $fileName;
        }
        $students->status = $request->roll;

        $students->save();
        return redirect()->back()->with('notify', 'Data saved successfully');
    }

    public function selectAllStudents()
    {
        $getData = Students::all();
        return view('frontend.student.index', compact('getData'));
    }

    public function deleteStudent($id)
    {
        $student = Students::find($id);
        unlink('db/images/student/' . $student->image);
        $student->delete();
        return redirect()->back();
    }

    public function edit($id)
    {
        $students = Students::find($id);
        return view('frontend.student.edit', compact('students'));
    }

    public function updateStudent(Request $request, $id)
    {
        $students = new Students();
        $request->validate([
            'name' => 'required | max:60',
            'email' => 'required | max: 60',
            'password' => 'required | min:4 | max:20',
            'image' => 'required'
        ]);

        $students = Students::find($id);
        $students->name = $request->name;
        $students->email = $request->email;
        $students->password = $request->password;

        if ($request->hasFile('image')) {
            $destination = 'db/images/student/' . $students->image;
            if (File::exists($destination)) {
                File::delete($destination);
            }
            $file = $request->file('image');
            $fileName = 'student' . strtolower(Str::random(10)) . time() . '.' . $file->getClientOriginalExtension();
            $file->move('db/images/student/', $fileName);
            $students->image = $fileName;
        }
        $students->status = $request->roll;

        $students->update();
        return redirect()->back()->with('notify', 'Data updated successfully');
    }
}
