

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_basic_batch11\crud\resources\views/frontend/home.blade.php ENDPATH**/ ?>