<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Students;
use Illuminate\Http\Request;

class StudentsController extends Controller
{
    public function index()
    {
        return view('frontend.student.index');
    }

    public function store()
    {
        return view('frontend.student.add');
    }

    public function insertStudent(Request $request)
    {

        $request->validate([
            'name' => 'required | max:60',
            'email' => 'required | max: 60',
            'password' => 'required | min:4 | max:8',
            'image' => 'required'
        ]); 

        $image = $request->image;
        $students = new Students();
        $students->name = $request->name;
        $students->email = $request->email;
        $students->password = $request->password;

        if ($image) {
            $folder = 'db/images/student/';
            $imageName = 'student' . time() . '.' . $image->getClientOriginalExtension();
            $image->move($folder, $imageName);
            $saveToDb = $folder . $imageName;
            $students->image = $saveToDb;
        }

        $students->save();
        return redirect()->back()->with('notify', 'Data saved successfully');
    }

    public function selectAllStudents()
    {
        $getData = DB::select("SELECT * FROM students");
        return view('frontend.student.index')->with('getData', $getData);
    }
}
