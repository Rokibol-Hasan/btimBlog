@extends('frontend.master')
@section('page-title')
    <h1 class="text-center py-5"> All Student </h1>
@endsection
@section('main')
    <section class="add-student-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card py-5 px-5 shadow-sm border-1">
                        <table id="example" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Serial</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Created_at</th>
                                    <th>action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($getData as $data)
                                    <tr>
                                        <td> {{ $loop->iteration }}</td>
                                        <td>{{ $data->name }}</td>
                                        <td>{{ $data->email }}</td>
                                        <td><img src="{{ $data->image }}" alt="" width="100px" height="80px"></td>
                                        @if ($data->status == '1')
                                            <td>{{ 'Admin' }}</td>
                                        @else
                                            <td>{{ 'General User' }}</td>
                                        @endif
                                        <td>{{ $data->created_at }}</td>
                                        <td>
                                            <a href="" class="btn btn-info">update</a>
                                            <a href="" class="btn btn-danger">delete</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
