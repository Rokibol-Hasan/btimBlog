
<?php $__env->startSection('page-title'); ?>
    <h1 class="text-center py-5"> All Student </h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <section class="add-student-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card py-5 px-5 shadow-sm border-1">
                        <table id="example" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Serial</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Created_at</th>
                                    <th>action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->email); ?></td>
                                        <td><img src="<?php echo e($data->image); ?>" alt="" width="100px" height="80px"></td>
                                        <?php if($data->status == '1'): ?>
                                            <td><?php echo e('Admin'); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e('General User'); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($data->created_at); ?></td>
                                        <td>
                                            <a href="" class="btn btn-info">update</a>
                                            <a href="" class="btn btn-danger">delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\php_basic_batch11\crud\resources\views/frontend/student/index.blade.php ENDPATH**/ ?>