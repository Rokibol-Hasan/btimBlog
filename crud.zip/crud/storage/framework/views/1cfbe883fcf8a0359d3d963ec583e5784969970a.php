<section class="page-title">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title-text">
                    <?php echo $__env->yieldContent('page-title'); ?>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH F:\xampp\htdocs\bitmProjects\crud\resources\views/frontend/blocks/page-title.blade.php ENDPATH**/ ?>