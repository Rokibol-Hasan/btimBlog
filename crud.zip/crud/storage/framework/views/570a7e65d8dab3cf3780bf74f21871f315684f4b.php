

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\bitmProjects\crud\resources\views/frontend/home.blade.php ENDPATH**/ ?>