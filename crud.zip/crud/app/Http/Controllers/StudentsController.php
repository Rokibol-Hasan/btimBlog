<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use App\Models\Students;
use Illuminate\Http\Request;

class StudentsController extends Controller
{
    public function index(){
        return view('frontend.student.index');
    }

    public function store(){
        return view('frontend.student.add');
    }

    public function insertStudent(Request $request){
        $students = new Students();
        $students->name = $request->name;
        $students->email = $request->email;
        $students->password = $request->password;

        $students->save();
        return redirect()->back()->with('notify','Data saved successfully');

    }

    public function selectAllStudents(){
        $getData = DB::select("SELECT * FROM students");
        return view('frontend.student.index')->with('getData', $getData);
    }
}
